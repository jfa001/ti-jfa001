
# Seguimiento de trabajos Individuales


**Categorías de calificación**
- 3: Funcionamiento correcto
- 2: Funcionamiento incorrecto en algunos casos de prueba
- 1: Funcionamiento incorrecto en todos los casos de prueba
- 0: No se ha implementado el programa


____________
## Trabajo individual 1

| Ejercicio/Apartado   |  Fecha de inicio |Finalizado|Calificación |
| ----------- | ---------------- |--------- |-------------|
| 1           |                  | [X]      |[2]          |
| 2           |                  | [ ]      |[0,1,2,3] |
| 3           |                  | [ ]      |
________________

____________
## Trabajo individual 2

| Ejercicio/Apartado   |  Fecha de inicio |Finalizado|Calificación |
| ----------- | ---------------- |--------- |-------------|
| 1           |                  | [ ]      |[0,1,2,3]         |
| 2           |                  | [ ]      |[0,1,2,3] |
________________
____________
## Trabajo individual 3

Resultado del test:  X/33

_________

____________
## Trabajo individual 4

| Ejercicio/Apartado   |  Fecha de inicio |Finalizado|Calificación |
| ----------- | ---------------- |--------- |-------------|
| 1           |                  | [ ]      |[0,1,2,3]         |
| 2           |                  | [ ]      |[0,1,2,3] |
________________

_______________
## Trabajo individual 5

| Ejercicio/Apartado   |  Fecha de inicio |Finalizado|Calificación |
| ----------- | ---------------- |--------- |-------------|
| 1           |                  | [ ]      |[0,1,2,3]         |

